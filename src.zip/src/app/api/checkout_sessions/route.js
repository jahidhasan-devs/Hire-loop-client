import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { PLAN_PRICE_ID, stripe } from "@/lib/stribe";
import { getUserSession } from "@/lib/core/session";

// import { stripe } from "../../../lib/stripe";

export async function POST(request) {
  try {
    const headersList = await headers();
    const origin = headersList.get("origin");

     const formData=await request.formData()
     const planId=formData.get('plan_id')
     const priceId = PLAN_PRICE_ID[planId];

  const user=await getUserSession()


    // Create Checkout Sessions from body params.
     const session = await stripe.checkout.sessions.create({
       customer_email: user?.email,
       line_items: [
         {
           // Provide the exact Price ID (for example, price_1234) of the product you want to sell
           price: priceId,
           quantity: 1,
         },
       ],
       mode: "subscription",
       metadata:{planId},
       success_url: `${origin}/plans/success?session_id={CHECKOUT_SESSION_ID}`,
       // Provide a name (for example, hosted_web_0001) to label this Checkout integration and measure its conversion independently
       integration_identifier: "hireloop_checkout",
     });
    return NextResponse.redirect(session.url, 303);
  } catch (err) {
    return NextResponse.json(
      { error: err.message },
      { status: err.statusCode || 500 },
    );
  }
}
